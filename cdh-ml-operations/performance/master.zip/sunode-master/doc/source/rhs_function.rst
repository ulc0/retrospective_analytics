.. _rhs-function:

Defining the right hand side function
=====================================

Todo
