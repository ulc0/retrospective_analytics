typedef float... realtype;
typedef int... sunindextype;
typedef int... booleantype;
typedef ... *N_Vector;
